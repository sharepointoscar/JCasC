Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 879.906GB left on /var/jenkins_home.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:1166/4193MB  Swap:1023/1023MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 40.715GB left on /tmp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
