Item statistics
===============


Total job statistics
======================

  * Number of jobs: 0
  * Number of builds per job: N/A
