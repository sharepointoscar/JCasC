Jenkins
=======

Version details
---------------

  * Version: `2.150.1`
  * Mode:    WAR
  * Url:     http://localhost:8080/
  * Java
      - Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_181
      - Maximum memory:   933.50 MB (978845696)
      - Allocated memory: 453.00 MB (475004928)
      - Free memory:      202.49 MB (212325520)
      - In-use memory:    250.51 MB (262679408)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.181-b13
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      4.9.125-linuxkit
  * Process ID: 8 (0x8)
  * Process started: 2019-01-31 20:27:45.719+0000
  * Process uptime: 1 min 0 sec
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
      - arg[0]: `-Duser.home=/var/jenkins_home`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `hudson.security.FullControlOnceLoggedInAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization
  * Support bundle anonymization: false

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * ant:1.9 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * apache-httpcomponents-client-4-api:4.5.5-3.0 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * artifactory:2.16.2 *(update available)* 'Jenkins Artifactory Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * blueocean:1.9.0 *(update available)* 'Blue Ocean'
  * blueocean-autofavorite:1.2.2 *(update available)* 'Autofavorite for Blue Ocean'
  * blueocean-bitbucket-pipeline:1.9.0 *(update available)* 'Bitbucket Pipeline for Blue Ocean'
  * blueocean-commons:1.9.0 *(update available)* 'Common API for Blue Ocean'
  * blueocean-config:1.9.0 *(update available)* 'Config API for Blue Ocean'
  * blueocean-core-js:1.9.0 *(update available)* 'Blue Ocean Core JS'
  * blueocean-dashboard:1.9.0 *(update available)* 'Dashboard for Blue Ocean'
  * blueocean-display-url:2.2.0 'Display URL for Blue Ocean'
  * blueocean-events:1.9.0 *(update available)* 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.9.0 *(update available)* 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.9.0 *(update available)* 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.9.0 *(update available)* 'i18n for Blue Ocean'
  * blueocean-jira:1.9.0 *(update available)* 'JIRA Integration for Blue Ocean'
  * blueocean-jwt:1.9.0 *(update available)* 'JWT for Blue Ocean'
  * blueocean-personalization:1.9.0 *(update available)* 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.9.0 *(update available)* 'Pipeline implementation for Blue Ocean'
  * blueocean-pipeline-editor:1.9.0 *(update available)* 'Blue Ocean Pipeline Editor'
  * blueocean-pipeline-scm-api:1.9.0 *(update available)* 'Pipeline SCM API for Blue Ocean'
  * blueocean-rest:1.9.0 *(update available)* 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.9.0 *(update available)* 'REST Implementation for Blue Ocean'
  * blueocean-web:1.9.0 *(update available)* 'Web for Blue Ocean'
  * bouncycastle-api:2.17 'bouncycastle API Plugin'
  * branch-api:2.1.2 'Branch API Plugin'
  * build-timeout:1.19 'Build Timeout'
  * cloudbees-bitbucket-branch-source:2.4.0 'Bitbucket Branch Source Plugin'
  * cloudbees-folder:6.7 'Folders Plugin'
  * command-launcher:1.2 *(update available)* 'Command Agent Launcher Plugin'
  * config-file-provider:3.4.1 *(update available)* 'Config File Provider Plugin'
  * configuration-as-code:1.3 *(update available)* 'Configuration as Code Plugin'
  * credentials:2.1.18 'Credentials Plugin'
  * credentials-binding:1.17 'Credentials Binding Plugin'
  * display-url-api:2.3.0 'Display URL API'
  * docker-commons:1.13 'Docker Commons Plugin'
  * docker-workflow:1.17 'Docker Pipeline'
  * durable-task:1.28 *(update available)* 'Durable Task Plugin'
  * email-ext:2.63 'Email Extension Plugin'
  * favorite:2.3.2 'Favorite'
  * git:4.0.0-rc 'Jenkins Git plugin'
  * git-client:3.0.0-rc 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * gitea:1.0.8 *(update available)* 'Gitea Plugin'
  * github:1.29.3 'GitHub plugin'
  * github-api:1.95 'GitHub API Plugin'
  * github-branch-source:2.4.2 'GitHub Branch Source Plugin'
  * gitlab-plugin:1.5.11 'GitLab Plugin'
  * gradle:1.30 'Gradle Plugin'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * handy-uri-templates-2-api:2.1.6-1.0 'Handy Uri Templates 2.x API Plugin'
  * htmlpublisher:1.17 *(update available)* 'HTML Publisher plugin'
  * ivy:1.28 'Ivy Plugin'
  * jackson2-api:2.9.8 'Jackson 2 API Plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jdk-tool:1.2 'JDK Tool Plugin'
  * jenkins-design-language:1.9.0 *(update available)* 'Jenkins Design Language'
  * jira:3.0.5 'Jenkins JIRA plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jsch:0.1.54.2 *(update available)* 'Jenkins JSch dependency plugin'
  * junit:1.26.1 'JUnit Plugin'
  * jx-resources:1.0.24 *(update available)* 'JX Resources Plugin'
  * kubernetes:1.13.7 *(update available)* 'Kubernetes plugin'
  * kubernetes-credentials:0.4.0 'Kubernetes Credentials Plugin'
  * kubernetes-credentials-provider:0.11 'Kubernetes Credentials Provider'
  * ldap:1.20 'LDAP Plugin'
  * lockable-resources:2.3 *(update available)* 'Lockable Resources plugin'
  * mailer:1.23 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:2.3 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.13 'Matrix Project Plugin'
  * maven-plugin:3.2 'Maven Integration plugin'
  * mercurial:2.4 *(update available)* 'Jenkins Mercurial plugin'
  * metrics:4.0.2.2 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * pam-auth:1.4 'PAM Authentication plugin'
  * pipeline-build-step:2.7 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:1.9 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.8 *(update available)* 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.3.3 *(update available)* 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.3.3 *(update available)* 'Pipeline: Declarative'
  * pipeline-model-extensions:1.3.3 *(update available)* 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.10 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.3 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.3.3 *(update available)* 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.10 'Pipeline: Stage View Plugin'
  * plain-credentials:1.4 *(update available)* 'Plain Credentials Plugin'
  * pubsub-light:1.12 'Jenkins Pub-Sub "light" Bus'
  * resource-disposer:0.12 'Resource Disposer Plugin'
  * scm-api:2.3.0 'SCM API Plugin'
  * script-security:1.49 *(update available)* 'Script Security Plugin'
  * simple-theme-plugin:0.5.1 'Simple Theme Plugin'
  * sse-gateway:1.16 *(update available)* 'Server Sent Events (SSE) Gateway Plugin'
  * ssh-credentials:1.14 'SSH Credentials Plugin'
  * ssh-slaves:1.29.4 'Jenkins SSH Slaves plugin'
  * structs:1.17 'Structs Plugin'
  * subversion:2.12.1 'Jenkins Subversion Plug-in'
  * support-core:2.52 *(update available)* 'Support Core Plugin'
  * timestamper:1.8.10 'Timestamper'
  * token-macro:2.5 *(update available)* 'Token Macro Plugin'
  * variant:1.1 'Variant Plugin'
  * workflow-aggregator:2.6 'Pipeline'
  * workflow-api:2.33 'Pipeline: API'
  * workflow-basic-steps:2.13 *(update available)* 'Pipeline: Basic Steps'
  * workflow-cps:2.61 *(update available)* 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.12 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.26 *(update available)* 'Pipeline: Nodes and Processes'
  * workflow-job:2.30 *(update available)* 'Pipeline: Job'
  * workflow-multibranch:2.20 'Pipeline: Multibranch'
  * workflow-scm-step:2.7 'Pipeline: SCM Step'
  * workflow-step-api:2.17 *(update available)* 'Pipeline: Step API'
  * workflow-support:2.23 *(update available)* 'Pipeline: Supporting APIs'
  * ws-cleanup:0.37 'Jenkins Workspace Cleanup Plugin'
