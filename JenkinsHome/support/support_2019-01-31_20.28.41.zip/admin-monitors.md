Monitors
========

`hudson.model.UpdateCenter$CoreUpdateMonitor`
--------------
(active and enabled)

`jenkins.diagnostics.URICheckEncodingMonitor`
--------------
(active and enabled)

`jenkins.security.UpdateSiteWarningsMonitor`
--------------
(active and enabled)
