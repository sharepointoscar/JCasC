Loggers currently enabled
=========================
winstone - INFO
org.apache.sshd - WARNING
 - INFO
